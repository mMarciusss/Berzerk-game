package workplace.model;

import lombok.Getter;
import lombok.Setter;

import java.awt.event.KeyEvent;

@Getter
@Setter

public class ShootParameters {
    private Player player;
    private KeyEvent e;
}
