package workplace.Enums;

public enum Direction {
    up, down, left, right;
}
